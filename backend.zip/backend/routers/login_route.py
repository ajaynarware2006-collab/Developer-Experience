from fastapi import APIRouter , HTTPException

from backend.services.auth_service import authenticate_user
from backend.services.session_service import login_user
from backend.repositories.profile_repository import (
    get_profile_by_user_id,
)
from backend.services.verification_service import create_email_verification
from backend.services.email_service import send_verification_code
from backend.schemas.user import Login

login_route = APIRouter(
    prefix="devxp",
    tags=["Login"]
)


@login_route.post("/authenticate_user")
def authenticate_user_route(userlogin : Login):

    user = authenticate_user(userlogin.email , userlogin.paswword)

    if user is None:
        raise HTTPException(
            status_code = 401,
            detail = "Unauthorized"
        )

    return user

    
