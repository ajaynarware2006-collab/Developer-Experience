from fastapi import APIRouter, HTTPException , Response

from backend.schemas.user import (
    UserCreate,
    UserResponse,
)

from backend.services.jwt_service import create_access_token
from backend.repositories.user_repository import create_user
from backend.repositories.user_repository import (
    create_user,
    get_user_by_email,
)

import secrets
import os
import requests
from urllib.parse import urlencode

from fastapi import APIRouter
from fastapi.responses import RedirectResponse
from dotenv import load_dotenv

load_dotenv()

router = APIRouter(
    prefix="/devxp",
    tags=["Authentication"],
)

GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID")
GOOGLE_REDIRECT_URI = os.getenv("GOOGLE_REDIRECT_URI")


@router.get("/auth/google")
def google_login():

    params = {
        "client_id": GOOGLE_CLIENT_ID,
        "redirect_uri": GOOGLE_REDIRECT_URI,
        "response_type": "code",
        "scope": "openid email profile",
    }

    google_url = (
        "https://accounts.google.com/o/oauth2/v2/auth?"
        + urlencode(params)
    )

    return RedirectResponse(google_url)


@router.get("/auth/google/callback")
def google_callback(code: str , response : Response):

    token_data = {
        "code": code,
        "client_id": os.getenv("GOOGLE_CLIENT_ID"),
        "client_secret": os.getenv("GOOGLE_CLIENT_SECRET"),
        "redirect_uri": os.getenv("GOOGLE_REDIRECT_URI"),
        "grant_type": "authorization_code"
    }

    response = requests.post(
        "https://oauth2.googleapis.com/token",
        data=token_data
    )

    if response.status_code != 200:
        raise HTTPException(
            status_code=400,
            detail="Failed to exchange Google authorization code"
        )

    tokens = response.json()

    access_token = tokens["access_token"]

    user_response = requests.get(
        "https://openidconnect.googleapis.com/v1/userinfo",
        headers={
            "Authorization": f"Bearer {access_token}"
        }
    )

    if user_response.status_code != 200:
        raise HTTPException(
            status_code=400,
            detail="Failed to get Google user information"
        )

    google_user = user_response.json()

    google_email = google_user["email"]
    google_name = google_user["name"]

    user = get_user_by_email(google_email)

    if not user:
        random_password = secrets.token_urlsafe(32)

        user = create_user(
            name=google_name,
            email=google_email,
            password=random_password
        )

    token = create_access_token(user.id)

    response.set_cookie(
        key="access_token",
        value=token,
        httponly=True,
        secure=False,
        samesite="lax",
        max_age=60 * 60
    )

    return {
        "message": "Google login successful"
    }


@router.post(
    "/signup",
    response_model=UserResponse,
)
def signup_user(data: UserCreate):

    try:

        user = create_user(
            name=data.name,
            email=data.email,
            password=data.password,
        )

    except ValueError as error:

        raise HTTPException(
            status_code=409,
            detail=str(error),
        )

    return user