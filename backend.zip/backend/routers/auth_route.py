from fastapi import APIRouter
from backend.schemas.user import UserCreate
from backend.repositories.user_repository import get_user_by_email ,create_user

router = APIRouter(
    prefix="/auth",
    tags=["Authentication"],
)


@router.post("/signup")
def signup_user(data : UserCreate ):
        
        try :

            user = create_user(data.name , data.email , data.password )

        except ValueError as error:
            return error
        
        return user






