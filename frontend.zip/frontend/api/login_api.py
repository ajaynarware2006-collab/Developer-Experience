from dotenv import load_dotenv
import requests
import os


load_dotenv()

API_BASE_URL = os.getenv("API_BASE_URL")

def authenticate_user_api(email , password):

    userlogin = {
        "email" : email,
        "password" : password
    }

    response = requests.post(f"{API_BASE_URL}/authenticate_user",json=userlogin)

    if response.status_code == 401:
        return None

    return response.json()
    