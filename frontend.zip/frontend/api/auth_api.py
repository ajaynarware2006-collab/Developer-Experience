from dotenv import load_dotenv
import requests
import os

load_dotenv()

API_BASE_URL = os.getenv("API_BASE_URL")


def signup_user(name , email , password):

    data = {
        "name" : name,
        "email" : email,
        "password" : password,
        }

    try:

        user = requests.post(f"{API_BASE_URL}/auth/signup",json=data)

    except ValueError as error:
        return error
    

    return user
